﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoverPersonaje2 : MonoBehaviour {
    public float movementSpeed = 5f;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        /*if (!Input.GetKey(KeyCode.UpArrow) && !Input.GetKey(KeyCode.DownArrow) && !Input.GetKeyUp(KeyCode.UpArrow) && !Input.GetKeyUp(KeyCode.DownArrow) && !Input.GetKeyDown(KeyCode.UpArrow) && !Input.GetKeyDown(KeyCode.DownArrow))
            transform.Translate(new Vector3(0f, 0f, Input.GetAxis("Vertical")) *
            Time.deltaTime
            * movementSpeed);
        if (!Input.GetKey(KeyCode.LeftArrow) && !Input.GetKey(KeyCode.RightArrow) && !Input.GetKeyUp(KeyCode.LeftArrow) && !Input.GetKeyUp(KeyCode.RightArrow) && !Input.GetKeyDown(KeyCode.LeftArrow) && !Input.GetKeyDown(KeyCode.RightArrow))
            transform.Rotate(new Vector3(0f, Input.GetAxis("Horizontal"), 0f));
            */

        if(Input.GetKey(KeyCode.A))
            transform.Rotate(new Vector3(0f, 1f, 0f));
        else if(Input.GetKey(KeyCode.D))
            transform.Rotate(new Vector3(0f, -1f, 0f));
        else if(Input.GetKey(KeyCode.W))
            transform.Translate(new Vector3(0f, 0f, 1f) *
            Time.deltaTime
            * movementSpeed);
        else if(Input.GetKey(KeyCode.S))
            transform.Translate(new Vector3(0f, 0f, -1f) *
            Time.deltaTime
            * movementSpeed);
    }
}
