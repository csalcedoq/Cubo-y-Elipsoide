﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoverPersonaje : MonoBehaviour {

    public float movementSpeed = 5f;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        //if(!Input.GetKey(KeyCode.W) && !Input.GetKey(KeyCode.S) && !Input.GetKeyUp(KeyCode.W) && !Input.GetKeyUp(KeyCode.S) && !Input.GetKeyDown(KeyCode.W) && !Input.GetKeyDown(KeyCode.S))
            transform.Translate(new Vector3( 0f , 0f , Input.GetAxis( "Vertical" ) ) * 
            Time.deltaTime 
            * movementSpeed);
        //if (!Input.GetKey(KeyCode.A) && !Input.GetKey(KeyCode.D) && !Input.GetKeyUp(KeyCode.A) && !Input.GetKeyUp(KeyCode.D) && !Input.GetKeyDown(KeyCode.A) && !Input.GetKeyDown(KeyCode.D))
            transform.Rotate( new Vector3( 0f , Input.GetAxis( "Horizontal" ) , 0f ) );
	}
}
